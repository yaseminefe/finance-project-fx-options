---
title: "Prices American Style"
output: html_document
date: "2025-03-19"
---




``` r
# Load necessary library
library(dplyr)
```

```
## 
## Attaching package: 'dplyr'
```

```
## The following objects are masked from 'package:stats':
## 
##     filter, lag
```

```
## The following objects are masked from 'package:base':
## 
##     intersect, setdiff, setequal, union
```

``` r
# Given exchange rates
exchange_rates <- c(
  0.90116, 0.945464, 0.968552, 0.977704, 0.979472, 1.003704, 1.011088, 
  1.012336, 1.013064, 1.013272, 1.04, 1.068704, 1.06964, 1.07016, 1.073072, 
  1.075984, 1.096472, 1.10292, 1.118416, 1.144832, 1.220024
)

# Given parameters
T <- 0.5  # 6 months until expiration
sigma <- 0.127  # 12.7% volatility
r_f <- 0.0218  # USD risk-free rate
strike_price <- 1.04  # At-the-money strike price

# Compute up (u) and down (d) factors
u <- exp(sigma * sqrt(T))
d <- 1 / u

# Compute risk-neutral probability (using mean of exchange rates)
q <- mean((exchange_rates - (exchange_rates * d)) / ((exchange_rates * u) - (exchange_rates * d)))

# Function to calculate 1-step American Call & Put Prices
american_binomial_option <- function(S0, X, u, d, q, T, r_f) {
    S_up <- S0 * u
    S_down <- S0 * d

    # Compute Call and Put Payoffs at Expiration
    C_up <- max(S_up - X, 0)
    C_down <- max(S_down - X, 0)
    P_up <- max(X - S_up, 0)
    P_down <- max(X - S_down, 0)

    # Discount Back to Present
    discount_factor <- exp(-r_f * T)
    C_0 <- discount_factor * (q * C_up + (1 - q) * C_down)
    P_0 <- discount_factor * (q * P_up + (1 - q) * P_down)

    return(data.frame(CallPrice = C_0, PutPrice = P_0))
}

# Compute option prices and profits
option_data <- lapply(exchange_rates, function(S0) {
    option_prices <- american_binomial_option(S0, strike_price, u, d, q, T, r_f)
    call_profit <- max(S0 - strike_price, 0) - option_prices$CallPrice
    put_profit <- max(strike_price - S0, 0) - option_prices$PutPrice
    return(data.frame(ExchangeRate = S0, option_prices, CallProfit = call_profit, PutProfit = put_profit))
})

# Combine results into a dataframe
df_options <- bind_rows(option_data)

# Print the dataframe
print(df_options)
```

```
##    ExchangeRate   CallPrice    PutPrice   CallProfit    PutProfit
## 1      0.901160 0.000000000 0.137334862  0.000000000  0.001505138
## 2      0.945464 0.000000000 0.093511153  0.000000000  0.001024847
## 3      0.968552 0.009237756 0.079911202 -0.009237756 -0.008463202
## 4      0.977704 0.013967253 0.075587914 -0.013967253 -0.013291914
## 5      0.979472 0.014880906 0.074752733 -0.014880906 -0.014224733
## 6      1.003704 0.027403323 0.063305845 -0.027403323 -0.027009845
## 7      1.011088 0.031219167 0.059817738 -0.031219167 -0.030905738
## 8      1.012336 0.031864099 0.059228198 -0.031864099 -0.031564198
## 9      1.013064 0.032240309 0.058884301 -0.032240309 -0.031948301
## 10     1.013272 0.032347797 0.058786044 -0.032347797 -0.032058044
## 11     1.040000 0.046160078 0.046160078 -0.046160078 -0.046160078
## 12     1.068704 0.060993499 0.032600674 -0.032289499 -0.032600674
## 13     1.069640 0.061477198 0.032158520 -0.031837198 -0.032158520
## 14     1.070160 0.061745919 0.031912878 -0.031585919 -0.031912878
## 15     1.073072 0.063250759 0.030537286 -0.030178759 -0.030537286
## 16     1.075984 0.064755599 0.029161695 -0.028771599 -0.029161695
## 17     1.096472 0.075343223 0.019483425 -0.018871223 -0.019483425
## 18     1.102920 0.078675368 0.016437472 -0.015755368 -0.016437472
## 19     1.118416 0.086683266 0.009117359 -0.008267266 -0.009117359
## 20     1.144832 0.103695536 0.000000000  0.001136464  0.000000000
## 21     1.220024 0.178072394 0.000000000  0.001951606  0.000000000
```

``` r
# Load necessary libraries
library(dplyr)
library(ggplot2)

# Given exchange rates
exchange_rates <- c(
  0.90116, 0.945464, 0.968552, 0.977704, 0.979472, 1.003704, 1.011088, 
  1.012336, 1.013064, 1.013272, 1.04, 1.068704, 1.06964, 1.07016, 1.073072, 
  1.075984, 1.096472, 1.10292, 1.118416, 1.144832, 1.220024
)

# Given parameters
S0 <- 1.04  # Current spot price
T <- 0.5    # 6 months until expiration
sigma <- 0.127  # Volatility
r_f <- 0.0218   # USD risk-free rate

# Compute up (u) and down (d) factors
u <- exp(sigma * sqrt(T))
d <- 1 / u

# Compute risk-neutral probability
q <- (S0 - (S0 * d)) / ((S0 * u) - (S0 * d))

# Strike price
strike_price <- 1.04  # At-the-money

# Function to calculate 1-step Binomial Option Prices
binomial_option <- function(S0, E, u, d, q, T, r_f) {
    S_up <- S0 * u
    S_down <- S0 * d

    # Compute Call and Put Payoffs at Expiration
    C_up <- max(S_up - E, 0)
    C_down <- max(S_down - E, 0)
    P_up <- max(E - S_up, 0)
    P_down <- max(E - S_down, 0)

    # Discount Back to Present
    discount_factor <- exp(-r_f * T)
    C_0 <- discount_factor * (q * C_up + (1 - q) * C_down)
    P_0 <- discount_factor * (q * P_up + (1 - q) * P_down)

    return(data.frame(StrikePrice = E, CallPrice = C_0, PutPrice = P_0))
}

# Compute Option Prices for Strike Price = 1.04
option_prices <- binomial_option(S0, strike_price, u, d, q, T, r_f)
call_premium <- option_prices$CallPrice
put_premium <- option_prices$PutPrice

# Compute Profit/Loss for Each Exchange Rate
profit_data <- data.frame(ExchangeRate = exchange_rates)

profit_data <- profit_data %>%
  mutate(
    CallProfit = pmax(ExchangeRate - strike_price, 0) - call_premium,
    PutProfit = pmax(strike_price - ExchangeRate, 0) - put_premium
  )

# Plot the Call and Put Profitability
ggplot(profit_data, aes(x = ExchangeRate)) +
  geom_line(aes(y = CallProfit, color = "Call Profit"), linewidth = 1.2) +
  geom_line(aes(y = PutProfit, color = "Put Profit"), linewidth = 1.2) +
  geom_hline(yintercept = 0, linetype = "dashed", color = "black") +
  
  # Shaded ITM & OTM Regions
  geom_rect(aes(xmin = min(ExchangeRate), xmax = strike_price, ymin = -Inf, ymax = Inf), fill = "red", alpha = 0.005) + # ITM Put
  geom_rect(aes(xmin = strike_price, xmax = max(ExchangeRate), ymin = -Inf, ymax = Inf), fill = "blue", alpha = 0.005) + # ITM Call

  # Labels
  annotate("text", x = strike_price, y = max(profit_data$CallProfit) * 0.5, 
           label = "Strike Price", hjust = -0.2, color = "black", size = 4) +
  annotate("text", x = min(exchange_rates) + 0.01, y = max(profit_data$PutProfit) , 
           label = "ITM Put", hjust = 0, color = "red", size = 4) +
  annotate("text", x = max(exchange_rates) - 0.01, y = max(profit_data$CallProfit) , 
           label = "ITM Call", hjust = 1, color = "blue", size = 4) +

  labs(title = "EUR/USD Call and Put Profitability",
       x = "EUR/USD Exchange Rates",
       y = "Profit/Loss") +
  scale_color_manual(values = c("Call Profit" = "blue", "Put Profit" = "red")) +
  theme_minimal()
```

<img src="american-options_files/figure-html/unnamed-chunk-2-1.png" width="672" />


